package com.human.dto;

public class HobbyDto {
	private int id;
	private String hobby;
	
	private String modifyHobby;
//	modify get
	public String getModifyHobby() {
		return modifyHobby;
	}
	public void setModifyHobby(String modifyHobby) {
		this.modifyHobby = modifyHobby;
	}
//	toString
	@Override
	public String toString() {
		return "HobbyDto [id=" + id + ", hobby=" + hobby + "]";
	}
//	getter setter
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHobby() {
		return hobby;
	}
	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	

}
