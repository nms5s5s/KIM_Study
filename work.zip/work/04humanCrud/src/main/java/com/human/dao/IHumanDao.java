package com.human.dao;

import java.util.ArrayList;

import com.human.dto.HumanDto;

public interface IHumanDao {
//	데이터를 입력하는 작업
	public void insert(HumanDto dto) throws Exception;
//	데이터를 업데이트 하는 작업
	public void update(HumanDto dto) throws Exception;
//	데이터를 지우는 작업
	public void delete(String name) throws Exception;
//	모든 데이터 읽어오는 작업
	public ArrayList<HumanDto> selectAll() throws Exception;
//	이름이 같은 한개 데이터를 가져오는 작업
	public HumanDto selectName(String name) throws Exception;
}
