package com.human.ex;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.human.dto.HumanDto;
import com.human.service.IHumanService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	@Autowired
	private IHumanService service;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 * @throws Exception 
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) throws Exception {
		
		ArrayList<HumanDto> list=service.selectAll();
		for(HumanDto dto:list) {
			System.out.println(dto);
		}
		
		return "home";
	}
//	게시글 리스트
	@RequestMapping(value = "/selectAll", method = RequestMethod.GET)
	public String selectAll(Model model) throws Exception {
		model.addAttribute("list", service.selectAll() );
		return "selectAll";
	}
//	글작성
	@RequestMapping(value = "/insert", method = RequestMethod.GET)
	public String insert() {
		return "insert";
	}
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public String insertDB(HumanDto humanDto,RedirectAttributes rttr) throws Exception{
		service.insert(humanDto);
		rttr.addFlashAttribute("msg","success");

		return "redirect:selectAll";
	}
//	상세페이지
	@RequestMapping(value = "/selectName", method = RequestMethod.GET)
	public String selectName(String name,Model model) throws Exception {
		model.addAttribute("dto", service.selectName(name) );
		return "selectName";
	}
//	글삭제
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String delete(String name,RedirectAttributes rttr) throws Exception {
		service.delete(name);
		rttr.addFlashAttribute("msg","success");
		return "redirect:selectAll";
	}
//	글수정
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String update(HumanDto humanDto) {
		System.out.println(humanDto);
		return "update";
	}
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String updateDB(HumanDto humanDto,RedirectAttributes rttr) throws Exception{
		service.update(humanDto);
		rttr.addFlashAttribute("msg","success");
		return "redirect:selectAll";
	}
	
}
