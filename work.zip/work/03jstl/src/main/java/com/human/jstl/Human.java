package com.human.jstl;

public class Human {
	
	private String name;
	private String age;
	
	
	public Human() {}
//	using
	public Human(String name, String age) {
		super();
		this.name = name;
		this.age = age;
	}
	
//	toString
	@Override
	public String toString() {
		return "Human [name=" + name + ", age=" + age + "]";
	}
	
//	Getter Setter
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
	

}
