package com.human.Dao;

import java.util.List;

import com.human.dto.BoardDto;

public interface IBoardDao {
//		게시글 작성
		public void create(BoardDto dto) throws Exception;
//		게시글 리스트
		public List<BoardDto> listAll() throws Exception;
}
